import React, { useContext } from 'react'
import { LoginContext } from './context/LoginContext'
import { useNavigate } from 'react-router-dom'
import './style/home.css';
import carParking from './images/orange car.png';
import v3 from './images/v3.png';
import v4 from './images/v4.png';
export default function Home() {
  let { userName } = useContext(LoginContext)
  const navigate = useNavigate();
  return (

    <div className='home'>
      <div className='cont'>
        <div className='content'>
          <div>
          <h1>Welcome to <span>ParkSpace</span></h1>
          <p>Your one-stop solution for hassle-free parking !</p>
         
            <button onClick={() => navigate('/malls')}>Search malls</button></div>
          <div className='imagePart' >
          <img src={carParking} alt="carParking" /></div>
        </div>
      </div>
    </div>

  )
}
