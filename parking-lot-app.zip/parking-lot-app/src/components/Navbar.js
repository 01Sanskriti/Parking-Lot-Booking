import React, { useContext, useState } from 'react'
import { LoginContext } from './context/LoginContext'
import { Link } from 'react-router-dom'


export default function Navbar() {
    let { isLogin, setIsLogin, userName, setUserName, isAdmin, setIsAdmin } = useContext(LoginContext)
   
    return (
        <div className={{}}>
            <nav className="navbar navbar-expand-lg bg-dark " data-bs-theme="dark">
                <div className="container-fluid">
                    <Link className="navbar-brand" href="#" style={{fontWeight:'900',fontSize:'28px'}}>Park<span style={{color:'#D16527'}}>Space</span></Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to='/'>Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to={'/malls'}>Malls</Link>
                            </li>
                            <li className="nav-item">
                                
                                {/* <Link className="nav-link active" aria-current="page" to={`/vehicles/${userName}`}>My Vehicles</Link> */}
                                <Link className="nav-link active" to={`/vehicles/${userName?.userName}`}>My Vehicles</Link>
                            </li>
                            
                            {/* {userName?.userName &&
    <li className="nav-item">
        <Link className="nav-link active" aria-current="page" to={`/vehicles/${userName.userName}`}>My Vehicles</Link>
    </li>
} */}
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/history">Booking History</Link>
                            </li>
                        </ul>
                        <div>
                            <ul className="navbar-nav me-2 mb-2 mb-lg-0">
                                {!isLogin &&
                                    <><li className="nav-item">
                                        <Link className="nav-link active" aria-current="page" to={'/login'}>Login</Link>
                                    </li><li className="nav-item">
                                            <Link className="nav-link active" aria-current="page" to={'/register'}>Register</Link>
                                        </li></>
                                }
                                {isLogin &&
                                    <li className="nav-item">
                                        <Link className="nav-link active" aria-current="page" onClick={() => {
                                            setIsLogin(false)
                                            setUserName(null)
                                            localStorage.clear();
                                        }}>Logout</Link>
                                    </li>}
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    )
}
