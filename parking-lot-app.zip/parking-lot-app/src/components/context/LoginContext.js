import { createContext, useEffect, useState } from "react";

export const LoginContext=createContext()

export function LoginProvider(props)
{
    let [isLogin,setIsLogin]=useState(false)
    let [isAdmin,setIsAdmin]=useState(false)
    let[userName,setUserName]=useState(null)
    useEffect(() => {
    const storedUser = localStorage.getItem("user");
    const storedLogin = localStorage.getItem("isLogin");
    const storedAdmin = localStorage.getItem("isAdmin");

    if (storedUser && storedLogin === "true") {
      setUserName(JSON.parse(storedUser));
      setIsLogin(true);
      setIsAdmin(storedAdmin === "true");
    }
  }, []);
    return (
        <LoginContext.Provider value={{isLogin,setIsLogin,userName,setUserName,isAdmin,setIsAdmin}}>
            {props.children}
        </LoginContext.Provider>
    )
}