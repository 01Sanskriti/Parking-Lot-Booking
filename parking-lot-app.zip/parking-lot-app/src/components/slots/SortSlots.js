import React from 'react'
export default function SortSlots(props) {
    return (
      <div className='dropdown'>
        <button class="btn btn-primary dropdown-toggle" style={{backgroundColor:'#D16527',border:'#D16527'}} type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Sort Slots</button>
      <ul className='dropdown-menu'>
        <li>
          <button className="dropdown-item" onClick={() => props.onSortSlot("availableFirst")}>
            Available First
          </button>
        </li>  
        <li>
          <button className="dropdown-item" onClick={() => props.onSortSlot("floorasc")}>
            Floor Ascending
          </button>
        </li>   
        <li>
          <button className="dropdown-item" onClick={() => props.onSortSlot("floordesc")}>
            Floor Descending
          </button>
        </li> 
    </ul>        
      </div>
    )
  }
