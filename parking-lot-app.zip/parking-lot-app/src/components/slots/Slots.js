import React, { useEffect, useState } from 'react'
import AllSlots from './AllSlots'
import FilterByAvailability from './FilterByAvailability';
import { useParams } from 'react-router-dom';
import SortSlots from './SortSlots';

export default function Slots() {
  const { mallId } = useParams(); 
  let [slots,setSlots]=useState(null)
  let[filteredSlots,setFilteredSlots]=useState(null)
  const getAllSlots=async(mallId)=>
    {
      let response=await fetch(`http://localhost:8080/parking-lot/mall/${mallId}/slots`)
      let slotData=await response.json()
      setSlots(slotData.data)
      setFilteredSlots(slotData.data)
     } 
     useEffect(()=>{getAllSlots(mallId)},[mallId])
     const getFloorNumber = (floor) => parseInt(floor); 
      const sortSlot=(sortingOrder)=>
        {
          let sorted=[...filteredSlots]
          if (sortingOrder === 'availableFirst') {
    sorted.sort((a, b) => a.occupied - b.occupied);
  } else if(sortingOrder==='floorasc'){
    sorted.sort((a, b) => getFloorNumber(a.floor) - getFloorNumber(b.floor));
  }else if(sortingOrder==='floordesc')
    {sorted.sort((a, b) => getFloorNumber(b.floor) - getFloorNumber(a.floor));}

  console.log("Sorted slots:", sorted);
          setFilteredSlots(sorted)
        }
     const filterByAvailability=(availability)=>
     {
      if(availability==="all")
      {
        setFilteredSlots(slots);
      }
      else
      {
        // let CheckOcc=slots.filter(slot=>{
        //   return slot.occupied.toLowerCase().includes(occupied.toLowerCase())
        //   setFilteredSlots(slots);
        // })
        const isOccupied =availability==="occupied"; 
        const filtered = slots.filter(slot => slot.occupied === isOccupied);
        setFilteredSlots(filtered);
      }
     
     }
  return ( 
    <div className='container mt-3'>
      <div className='d-flex justify-content-between'>
      <FilterByAvailability onFilterByAvailability={filterByAvailability}/>
      <SortSlots onSortSlot={sortSlot}/>
      </div>
      <AllSlots allSlots={filteredSlots}/>
    </div>
  )  
}
