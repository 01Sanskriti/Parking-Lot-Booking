import React from 'react'

export default function FilterByAvailability(props) {
  return (
    <div className='dropdown'>
        <button className='btn btn-secondary dropdown-toggle' type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Slots
        </button>
        <ul className='dropdown-menu' >
            <li>
                <button className='dropdown-item' onClick={()=>{props.onFilterByAvailability("all")}}>All Slots</button>
            </li>
            <li>
                <button className='dropdown-item' onClick={()=>{props.onFilterByAvailability("available")}}>Available</button>
            </li>
            <li>
                <button className='dropdown-item' onClick={()=>{props.onFilterByAvailability("occupied")}}>Unavailable</button>
            </li>
        </ul>
    </div>
  )
}
