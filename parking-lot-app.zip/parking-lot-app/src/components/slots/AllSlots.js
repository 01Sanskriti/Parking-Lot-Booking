import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../style/slot.css";
import sedan from "../images/sedan.png";
import greencar from "../images/green_sedan1-Photoroom.png";
import redcar from "../images/red_sedan1-Photoroom.png";

export default function AllSlots(props) {
  const { mallId } = useParams();
  const navigate = useNavigate();
  let slots = props.allSlots;
  const handleSlotClick = (slot) => {
    if (!slot.occupied) {
      navigate(`/payment/${slot.id}`);
    }
  };

  return (
    <div className="mt-3">
      <div className="row">
        {/* <h1 style={{color:'#D16527',fontSize:'25px',textAlign:'center',fontWeight:'900',textDecoration:'underline'}}>Click on Green slots to make payment</h1> */}
        {slots &&
          slots.map((slot) => {
            console.log(slot.id, slot.occupied, typeof slot.occupied);
            return (
              <div className="col-3 mb-3" key={slot.id}>
<div className="text-center mb-1" style={{color:'white',fontSize:'25px'}}>
    <strong>{slot.slotNo}</strong>
  </div>                <img
                  src={slot.occupied ? redcar : greencar}
                  alt={slot.occupied ? "Occupied Slot" : "Available Slot"}
                  className="slot "
                  style={{
                    width: "15rem",
                    cursor: slot.occupied ? "not-allowed" : "pointer",
                    marginTop:'-50px'
                  }}
                  
                  onClick={() => handleSlotClick(slot)}
                >
                  {/* <div className="card-body">
                                <h5 className="card-title text-center">{slot.type.toUpperCase()}</h5>
                                {!slot.occupied && (
                                    <p className="text-center text-white">Click to Book</p>
                                )} */}
                  {/* {!slot.occupied &&(
                                    <p className="text-center text-white">Occupied</p>
                                )} */}
                </img>
              </div>
              // </div>
            );
          })}
      </div>
    </div>
  );
}
