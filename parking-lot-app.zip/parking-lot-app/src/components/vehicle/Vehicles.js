import React, { useContext, useEffect, useState } from 'react'
import AllVehicles from './AllVehicles'
import { useNavigate, useParams } from 'react-router-dom';
import { LoginContext } from '../context/LoginContext';
// import FilterVehicleByType from './FilterVehicleByType'
// import SearchVehicle from './SearchVehicle'
// import SortVehicleByPrice from './SortVehicleByPrice'

export default function Vehicles() {
   const { userName } = useContext(LoginContext);
   console.log("userName in Vehicles page:", userName);
   const navigate = useNavigate();
  let [vehicles, setVehicles]=useState(null)
  let [filteredVehicles, setFilteredVehicles]=useState(null)
  const getAllVehicles= async() =>
    {
      const usernameString = userName?.userName;
      console.log("Fetching for user:", usernameString);
      // console.log(`Fetching vehicles from: http://localhost:8080/parking-lot/vehicles/${usernameString}/vehicles`);
      let response=await fetch(`http://localhost:8080/parking-lot/vehicles/${usernameString}/vehicles`)
      let vehicleData=await response.json()
      console.log("Vehicle API Data:", vehicleData)
      setVehicles(vehicleData.data)
      setFilteredVehicles(vehicleData.data)
    }
    // useEffect(()=>{getAllVehicles()},[])
      useEffect(() => {
    if (userName?.userName) {
      getAllVehicles();
    }
  }, [userName]);

  return (
    <div className='container mt-3'>
      
      <div className='d-flex justify-content-between'>
      </div>
      <AllVehicles allVehicles={filteredVehicles}/>
        <button className='btn btn-primary text-center w-100 ml-50 mr-50 'onClick={() => navigate('/register-vehicle')} style={{backgroundColor:'#D16527',border:'#D16527'}}>Add vehicles</button>
    </div>
  )
}
