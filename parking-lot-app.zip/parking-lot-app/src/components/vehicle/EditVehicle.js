import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';

export default function EditVehicle() {
  const { id } = useParams();
  const navigateTo = useNavigate();
  const [initialData, setInitialData] = useState(null);
  const { register, handleSubmit, setValue, formState: { errors } } = useForm();

  useEffect(() => {
     console.log("Component mounted. Vehicle ID:", id);
    const fetchVehicle = async () => {
      const response = await fetch(`http://localhost:8080/parking-lot/vehicles/${id}`);
      const data = await response.json();
      const vehicle = data.data;
      setInitialData(vehicle);
      setValue('model', vehicle.model);
      setValue('registrationNumber', vehicle.registrationNumber);
      setValue('type', vehicle.type);
    };

    fetchVehicle();
  }, [id, setValue]);

  const onSubmit = async (formData) => {
    const response = await fetch(`http://localhost:8080/parking-lot/vehicles/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const result = await response.json();
    console.log("Update result:", result);
    navigateTo('/vehicles/' + initialData.customer?.userName);
  };

  if (!initialData) return <div>Loading...</div>;

  return (
    <div className="container mt-5">
      <h2>Edit Vehicle</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-3">
          <label>Model</label>
          <input className="form-control" {...register('model', { required: true })} />
          {errors.model && <p className="text-danger">Model is required</p>}
        </div>

        <div className="mb-3">
          <label>Registration Number</label>
          <input
            className="form-control"
            {...register('registrationNumber', { required: true, minLength: 10, maxLength: 10 })}
          />
          {errors.registrationNumber && <p className="text-danger">Valid registration number required</p>}
        </div>

        <div className="mb-3">
          <label>Type</label>
          <select className="form-select" {...register('type', { required: true })}>
            <option value="two">Two Wheeler</option>
            <option value="four">Four Wheeler</option>
          </select>
        </div>

        <button type="submit" className="btn btn-success">Update Vehicle</button>
      </form>
    </div>
  );
}
