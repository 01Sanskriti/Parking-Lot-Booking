import React,{useContext} from 'react'
import { useForm } from 'react-hook-form';
import { LoginContext } from '../context/LoginContext';
import { useNavigate } from 'react-router-dom';


export default function AddVehicles() {
    let {register, handleSubmit, watch, formState: { errors }}=useForm()
    let{userName}=useContext(LoginContext)
    let navigateTo=useNavigate()
    const handleFormData=async (formData)=>{
          console.log("Sending vehicle data to backend:", formData);
        formData.customer={id:userName.id}
        let response=await fetch("http://localhost:8080/parking-lot/register-vehicle",
            {
                method:"POST",
                                      headers:{"Content-Type":"application/json"},
                                      body:JSON.stringify(formData)
            })
            let responseData=await response.json()
            // console.log(responseData);
             console.log("Response:", responseData);
            navigateTo('/malls')
            
    }
    return (
      <div  className='container d-flex justify-content-center mt-5'>
        <form className='w-50' onSubmit={handleSubmit(handleFormData)}>
            <h1 className='text-center'>Add Vehicle </h1>
          <div className="mb-3">
            <input type="text" className="form-control" placeholder='Registration Number'
            {...register('registrationNumber',{required:true, minLength:10,maxLength:10})}/>
            <div id="registrationNumber" className="form-text text-danger">
                  {errors.registrationNumber?.type === 'required' && 'registrationNumber is required'}
                  {errors.registrationNumber?.type === 'minLength' && 'registrationNumber must have exactly 10 characters'}
                  {errors.registrationNumber?.type === 'maxLength' && 'registrationNumber must have exactly 10 characters'}
            </div>
           </div>
           <div className="mb-3">
                <select class="form-select" {...register('type')}>
                    <option value={'two'}>Two Wheeler</option>
                    <option value={'four'}>Four Wheeler</option>
                </select>
          </div>
          <div className="mb-3">
            <input type="text" className="form-control" placeholder='model'
            {...register('model',{required:true})}/>
            <div id="model" className="form-text text-danger">
                  {errors.model?.type === 'required' && 'model is required'}
            </div>
          </div>
           <button type="submit" className="btn btn-primary w-100">Add Vehicle</button>

        </form>

      </div>
    )
  
}
