import React from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
export default function AllVehicles(props) {
let vehicles = props.allVehicles
const setVehicles = props.setVehicles;
const navigate = useNavigate();
const handleDelete = async (id) => {
    const confirm = window.confirm("Are you sure you want to delete this vehicle?");
    if (!confirm) return;

    try {
      const response = await fetch(`http://localhost:8080/parking-lot/vehicles/${id}`, {
        method: "DELETE",
      });
      const result = await response.json();
      console.log("Deleted:", result);
      setVehicles((prev) => prev.filter((v) => v.id !== id));
    } catch (error) {
      console.error("Delete failed", error);
    }
  };
  return (
    <div className='mt-3'>
        <div className='row'>
            {
                vehicles && vehicles.map(vehicle => {
                    return(
                    <div className='col-3 mb-3' key={vehicle.id}>
                        <div className="card" style={{width:15+"rem"}}>
                            <img src="http://localhost:3000/bike.png" className="card-img-top" alt="..."/>
                            <div className="card-body">
                                <h5 className="card-title text-center">{vehicle.model.toUpperCase()}</h5>
                                <ul >
                                    
                                    <li>Number - {vehicle.registrationNumber}</li>
                                    
                                </ul>
                                    <button className='btn btn-primary' 
                                    style={{marginRight:'50px',marginLeft:'5px',width:'70px'}} 
                                    onClick={() => navigate(`/edit-vehicle/${vehicle.id}`)}>Edit</button>
                                    
                                        <button className='btn btn-danger' onClick={() => handleDelete(vehicle.id)}>Delete</button>
                                {/* <button onClick={() => navigate('/malls')}>Book Now</button> */}
                            </div>
                        </div>
                    </div>
                    )
                })
                    
                
            }
        </div>
    </div>
  )
}
