import React, { useContext, useState } from 'react'
import { LoginContext } from '../context/LoginContext'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'

export default function LoginCustomer() {
    let { setIsLogin, setUserName, setIsAdmin } = useContext(LoginContext)
    let { register, handleSubmit, watch, formState: { errors } } = useForm()
    let [crendentialsMessage, setCredentialsMessage] = useState(null)
    let navigateTo = useNavigate()
    const handleFormData = async (formData) => {
        console.log(formData);
        let response = await fetch("http://localhost:8080/parking-lot/login",
            {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData)
            }
        )
        let responseData = await response.json()
        console.log(responseData);
        if (responseData.data != null) {
            if (responseData.data.userName === 'admin') {
                setIsAdmin(true)
            }
            setIsLogin(true);
const user = { id: responseData.data.id, userName: responseData.data.userName };
setUserName(user);
localStorage.setItem("user", JSON.stringify(user));
localStorage.setItem("isLogin", "true");


navigateTo(`/vehicles/${responseData.data.userName}`);

        }
        else {
            console.log(responseData.message);
            setCredentialsMessage(responseData.message)
        }
    }
    return (
        <div className='container d-flex justify-content-center mt-5'>
            <form className='w-50'onSubmit={handleSubmit(handleFormData)}>
                <h1 className='text-center'>Login</h1>
                {
                    crendentialsMessage && <div className='alert alert-danger alert-dismissible fade show' role="alert">
                        <strong>{crendentialsMessage}!</strong>
                    </div> 
                }
                <div className="mb-3">
                    <input type="text" className="form-control" placeholder='UserName'
                        {...register('userName', { required: true, minLength: 3, maxLength: 10 })} />
                    <div id="userName" className="form-text text-danger">
                        {errors.userName?.type === 'required' && 'Username is required'}
                        {errors.userName?.type === 'minLength' && 'min 3 characters required'}
                        {errors.userName?.type === 'maxLength' && 'max 10 characters allowed'}
                    </div>
                </div>
                <div className="mb-3">
                    <input type="password" className="form-control" placeholder='Password'
                        {...register('password', { required: true, minLength: 3, maxLength: 10 })} />
                    <div id="password" className="form-text text-danger">
                        {errors.password?.type === 'required' && 'password is required'}
                        {errors.password?.type === 'minLength' && 'min 3 characters required'}
                        {errors.password?.type === 'maxLength' && 'max 10 characters allowed'}
                    </div>
                </div>
                <button type="submit" className="btn btn-primary w-100">Login</button>
            </form>
        </div>
    )
}
