import React from 'react'
import { useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'

export default function RegisterCustomer() {
    let { register, handleSubmit, watch, formState: { errors } } = useForm()
    let navigateTo = useNavigate()
    const handleFormData = async (formData) => {
        console.log(formData);
        let response = await fetch("http://localhost:8080/parking-lot/register",
            {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData)
            }
        )
        let responseData = await response.json()
        console.log(responseData);
        navigateTo('/login')

    }
    return (
        <div className='container d-flex justify-content-center mt-5'>
            <form className='w-50' onSubmit={handleSubmit(handleFormData)}>
                <h1 className='text-center'>Register</h1>
                <div className="mb-3">
                    <input type="text" className="form-control" placeholder='UserName'
                        {...register('userName', { required: true, minLength: 3, maxLength: 10 })} />
                    <div id="userName" className='form-text text-danger'>
                        {errors.userName?.type === 'required' && 'Username is required'}
                        {errors.userName?.type === 'minLength' && 'min 3 characters required'}
                        {errors.userName?.type === 'maxLength' && 'max 10 characters allowed'}
                    </div>
                </div>
                <div className="mb-3">
                    <input type="number" className="form-control" placeholder='Phone'
                        {...register('phone', { required: true, minLength: 3, maxLength: 10 })} />
                    <div id="phone" className='form-text text-danger'>
                        {errors.phone?.type === 'required' && 'phone is required'}
                        {errors.phone?.type === 'minLength' && 'phone number must have exactly 10 numbers'}
                        {errors.phone?.type === 'maxLength' && 'phone number must have exactly 10 numbers'}
                    </div>
                </div>
                <div className="mb-3">
                    <input type="password" className="form-control" placeholder='Password'
                        {...register('password', { required: true, minLength: 3, maxLength: 10 })} />
                    <div id="password" className='form-text text-danger'>
                        {errors.password?.type === 'required' && 'password is required'}
                        {errors.password?.type === 'minLength' && 'min 3 characters required'}
                        {errors.password?.type === 'maxLength' && 'max 10 characters allowed'}
                    </div>
                </div>
                <div className="mb-3">
                    <input type="password" className="form-control" placeholder='Confirm Password'
                        {...register('confirmPassword', {
                            validate: (value) => {
                                if (value === watch('password')) { return true }
                                else { return "Passwords do not match !!" }

                            }
                        })} />
                  {errors.confirmPassword && <div className="form-text text-danger">{errors.confirmPassword.message}</div>}
                </div>



                <button type="submit" className="btn btn-primary w-100">Register</button>
            </form>
        </div>
    )
}
