import React, { useContext, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { LoginContext } from '../context/LoginContext';

export default function BookingPayment() {
  const { slotId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { userName } = useContext(LoginContext); 

  const { register,setValue ,handleSubmit, formState: { errors } } = useForm();
  const [message, setMessage] = useState('');

  const vehicleRegistrationId = location.state?.vehicleId; 
  useEffect(() => {
  setValue("amount", 50);
}, [setValue]);
  const onSubmit = async (formData) => {
    const paymentData = {
      slotId: parseInt(slotId),
      customerId: userName.id,
      vehicleRegistrationId: vehicleRegistrationId,
      amount: parseFloat(formData.amount),
      paymentMethod: formData.paymentMethod,
      status: 'Completed',
    };

    try {
      const response = await fetch('http://localhost:8080/parking-lot/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paymentData),
      });

      const result = await response.json();
      if (response.ok) {
        setMessage("Payment Successful!");
        navigate('/');
      } else {
        setMessage(result.message || "Payment failed");
      }
    } catch (error) {
      console.error("Payment Error:", error);
      setMessage("Error occurred during payment");
    }
  };


  return (
    <div className="container mt-5">
      <h2>Complete Payment</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit(onSubmit)} className="w-50 mx-auto">
        <div className="mb-3">
          <label style={{color:"white",marginBottom:"5px"}}>Amount</label>
          <input
            type="number"
            className="form-control"
            step="0.01" readOnly
            {...register('amount', { required: true, min: 1 })} 
          />
          {errors.amount && <p className="text-danger">Valid amount required</p>}
        </div>

        <div className="mb-3">
          <label style={{color:"white",marginBottom:"5px"}} >Payment Method</label>
          <select className="form-select" {...register('paymentMethod', { required: true })}>
            <option value="">Select Payment Method</option>
            <option value="Card">Card</option>
            <option value="UPI">UPI</option>
            <option value="NetBanking">Net Banking</option>
            <option value="Cash">Cash</option>
          </select>
          {errors.paymentMethod && <p className="text-danger">Please select a method</p>}
        </div>

        <button type="submit" className="btn btn-success w-100">Pay Now</button>
      </form>
    </div>
  );
}