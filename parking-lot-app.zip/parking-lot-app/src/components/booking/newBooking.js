import React, { useContext, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { LoginContext } from "../context/LoginContext";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import "../style/booking.css";

export default function NewBooking() {
  let {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  let { userName } = useContext(LoginContext);
  // let{mallName}=useContext(LoginContext)
  let navigateTo = useNavigate();
  let { mallId } = useParams();
  const location = useLocation();
  const { mallName } = location.state || {};
  const [userVehicles, setUserVehicles] = useState([]);
  useEffect(() => {
    const fetchVehicles = async () => {
      if (!userName?.userName) return;
      try {
        const response = await fetch(
          `http://localhost:8080/parking-lot/vehicles/${userName.userName}/vehicles`
        );
        const data = await response.json();
        setUserVehicles(data.data || []);
      } catch (error) {
        console.error("Error fetching vehicles:", error);
      }
    };

    fetchVehicles();
  }, [userName]);
  const handleFormData = async (formData) => {
    console.log(formData);
    const selectedVehicle = userVehicles.find(
      (vehicle) => vehicle.id === parseInt(formData.vehicleId)
    );

    const finalBookingData = {
      customer: userName,
      mallId,
      registrationNumber: selectedVehicle?.registrationNumber,
    };
    // formData.mallName=mallName
    console.log("Final Booking Payload:", finalBookingData);

    let response = await fetch("", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(finalBookingData),
    });
    let responseData = await response.json();
    console.log(responseData);
    navigateTo("/bookSlot");
  };
  const handleViewAllSlots = () => {
    navigateTo(`/slots/${mallId}/all`);
  };
  return (
    <div className="container d-flex justify-content-center mt-5">
      <form className="w-50" onSubmit={handleSubmit(handleFormData)}>
        <h1 className="text-center">Booking Details</h1>
        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="username"
            defaultValue={userName?.userName || ""}
            readOnly
            {...register("customer")}
          />

          {/* <input type="text" className="form-control" placeholder='username' defaultValue={userName ||''} readOnly {...register('customer')}/> */}
        </div>
        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="mallName"
            defaultValue={mallName || ""}
            readOnly
            {...register("mallName")}
          />
        </div>
        {/* <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="registrationNumber"
            {...register("registrationNumber", {
              required: true,
              minLength: 10,
              maxLength: 10,
            })}
          />
          <div id="registrationNumber" className="form-text text-danger">
            {errors.registrationNumber?.type === "required" &&
              "registrationNumber is required"}
            {errors.registrationNumber?.type === "minLength" &&
              "registrationNumber must have exactly 10 characters"}
            {errors.registrationNumber?.type === "maxLength" &&
              "registrationNumber must have exactly 10 characters"}
          </div>
          

        </div> */}
        <div className="mb-3">
          <select className="form-select" {...register('vehicleId', { required: true })}>
            <option value="">Select Your Vehicle</option>
            {
              userVehicles.map(vehicle => (
                <option key={vehicle.id} value={vehicle.id}>
                  {vehicle.model.toUpperCase()} - {vehicle.registrationNumber}
                </option>
              ))
            }
          </select>
          <div className="form-text text-danger">
            {errors.vehicleId?.type === 'required' && 'Please select a vehicle'}
          </div>
        </div>
        <button
          className="btn btn-outline-primary w-100 buttonSlot"
          onClick={handleViewAllSlots}
        >
          {" "}
          View All Slots
        </button>
      </form>
    </div>
  );
}
