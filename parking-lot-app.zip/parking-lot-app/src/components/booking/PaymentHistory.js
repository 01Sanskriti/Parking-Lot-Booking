import React, { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { LoginContext } from '../context/LoginContext'

export default function PaymentHistory() {
    let[payments,setPayments]=useState(null)
    let [filteredPayments,setFilteredPayments]=useState(null)
    let {userName}=useContext(LoginContext)
    const getAllPayments=async()=>
        {
            let response=await fetch(`http://localhost:8080/parking-lot/payment/customer/${userName.id}`)
            let paymentData=await response.json()
            setPayments(paymentData.data)
            setFilteredPayments(paymentData.data)
        }
        useEffect(()=>{getAllPayments()},[])
  return (
     <div className='container mt-3'>
            <div className=' border border-3 rounded-4 p-3'>
                <h3 style={{textAlign:"center",color:"#D16527"}}>Booking History</h3>
            </div>
            <div className='border border-3 rounded-4 p-3 mt-1'>
                <table class="table table-hover text-center">
                    <thead>
                        <tr>
                            <th>Slot ID</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            payments && payments.map(payment => {
                                return(
                                    <tr>
                                        <th>{payment.slotId}</th>
                                        <th>{payment.paymentMethod}</th>
                                        <th>{payment.status}</th>
                                        <th>{payment.amount}</th>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </div>
      
  )
}
