import React from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import '../style/mall.css';
export default function AllMalls(props) {
    let malls = props.allMalls
    const navigate=useNavigate();
    const handleBookSlot=(mallId,mallName)=>{navigate(`/slots/${mallId}`,{state:{mallName}})}
    return (
        <div className='mt-3'>
            <div className='row'>
                {
                    malls && malls.map(mall => {
                        return (
                            <div className='col-3 mb-3 mainContent' key={mall.id}>
                                <div className="card" style={{width: 18+"rem"}}>
                                <img src={mall.imageUrl} className="card-img-top" alt="..." />
                                <div className="card-body cBody">
                                    <h5 className="card-title text-center" >{mall.name.toUpperCase()}</h5>
                                    <p className="card-text" >Location - {mall.location}</p>
                                    <button  className="btn btn-primary" onClick={()=>handleBookSlot(mall.id,mall.name)} >Book Slots</button>
                                </div>
                            </div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}
