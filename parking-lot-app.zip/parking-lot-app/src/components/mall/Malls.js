import React, { useEffect, useState } from 'react'
import AllMalls from './AllMalls'
import FilterMallByLocation from './FilterMallByLocation'
import SearchMall from './SearchMall'
import '../style/mall.css';

export default function Malls() {
    let [malls,setMalls]=useState(null)
    let [filteredMalls,setFilteredMalls]=useState(null)
    const getAllMalls =async()=>
    {
        let response= await fetch("http://localhost:8080/parking-lot/malls")
        let mallData=await response.json()
        setMalls(mallData.data)
        setFilteredMalls(mallData.data)
    }
    useEffect(()=>{getAllMalls()},[])

    const filterMallByLocation=(location)=>
        {
            if(location==='all')
                {
                    getAllMalls()
                    console.log(getAllMalls());
                    
                }
            else
                {
                    let newMalls=malls.filter(mall=>
                        {
                            return mall.location?.toLowerCase().includes(location.toLowerCase())
                        })
                        setFilteredMalls(newMalls)
                }
        }
        const searchMallByName=(mallName)=>{
            if(!mallName?.trim()){
                setFilteredMalls(malls);
                return;
            }
            let searchedMalls=[...filteredMalls]
            let newMalls=searchedMalls.filter((mall)=>
             mall.name?.toLowerCase().includes(mallName.toLowerCase())
        );
            setFilteredMalls(newMalls)
        };

  return (
    <div className='container mt-3'>
        <div className='d-flex justify-content-between'>
            <FilterMallByLocation onFilterMallByLocation={filterMallByLocation}/>
            <SearchMall onSearchMallByName={searchMallByName}/>
        </div>
        <AllMalls allMalls={filteredMalls}/>
    </div>
  ) 
}
