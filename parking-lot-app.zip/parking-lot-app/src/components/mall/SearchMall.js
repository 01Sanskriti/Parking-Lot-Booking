import React from 'react'
import { useForm } from 'react-hook-form'
import '../style/mall.css';

export default function SearchMall(props) {
  let {register,handleSubmit,formState:{errors}}=useForm()
  const collectFormData=(formData)=>{
    console.log(formData)
    props.onSearchMallByName(formData.mall)
  }
  return (
    <div>
      <form onSubmit={handleSubmit(collectFormData)}>
        <div className="d-flex">
          <input type="text" className="form-control" id="name"
          placeholder='Search Mall' {...register('mall',{required:true})}/>
          
          <input type='submit' className='btn btn-primary ms-2 buttonColor'/>
        </div>
        {errors.mall?.type==='required'&& <div className="form-text text-danger">Mall name is required</div>
        }
      </form>
    </div>
  ) 
}
