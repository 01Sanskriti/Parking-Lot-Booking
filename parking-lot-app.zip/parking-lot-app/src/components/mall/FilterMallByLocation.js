import React from 'react'
import '../style/mall.css';

export default function FilterMallByLocation(props) {
    return (
<div className="dropdown">
    <button className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        Location 
    </button>
    <ul className="dropdown-menu">
        <li>
            <button className="dropdown-item" onClick={()=>{props.onFilterMallByLocation("all")}}>All Locations</button>
        </li>
        <li>
            <button className="dropdown-item" onClick={()=>{props.onFilterMallByLocation("airoli")}}>Airoli</button>
        </li>
        <li>
            <button className="dropdown-item" onClick={()=>{props.onFilterMallByLocation("dadar")}}>Dadar </button>
        </li>
        <li>
            <button className="dropdown-item" onClick={()=>{props.onFilterMallByLocation("kalyan")}}>Kalyan </button>
        </li>
        <li>
            <button className="dropdown-item" onClick={()=>{props.onFilterMallByLocation("thane")}}>Thane </button>
        </li>
    </ul>      
</div>
    )
} 
