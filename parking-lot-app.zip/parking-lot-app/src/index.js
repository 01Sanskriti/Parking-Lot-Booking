import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import ErrorPage from './components/ErrorPage';
import RegisterCustomer from './components/customer/RegisterCustomer';
import LoginCustomer from './components/customer/LoginCustomer';
import { LoginProvider } from './components/context/LoginContext';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import Vehicles from './components/vehicle/Vehicles';
import SearchMall from './components/mall/SearchMall';
import Malls from './components/mall/Malls';
import Slots from './components/slots/Slots';
import NewBooking from './components/booking/newBooking';
import BookingPayment from './components/booking/BookingPayment';
import AllVehicles from './components/vehicle/AllVehicles';
import AddVehicles from './components/vehicle/AddVehicles';
import EditVehicle from './components/vehicle/EditVehicle';
import PaymentHistory from './components/booking/PaymentHistory';
// import EditVehicle from './components/vehicle/EditVehicle';
// import 


const routes=createBrowserRouter([
    {
        path:'/',
        element:<App/>,
        errorElement:<ErrorPage/>,
        children:[
            {
                index:true,
                element:<Home/>,
            },
            {
                path:'/register',
                element:<RegisterCustomer/>,
            },
            {
                path:'/login',
                element:<LoginCustomer/>,
            },
            {
                path:'/vehicles/:userName',
                // path:'/vehicles',
                element:<Vehicles/>,
            },
            {
                path:'/malls',
                element:<Malls/>,
            },
            {
                path:'/history',
                element:<PaymentHistory/>,
            },
            {
                path:'/slots/:mallId',
                element:<NewBooking/>
            },
            {
                path:'/slots/:mallId/all',
                element:<Slots/>
            },
            {
                path:'/payment/:slotId',
                element:<BookingPayment/>
            },
            // {
            //     path:'/vehicles/register-vehicle',
            //     element:<AddVehicles/>
            // },
            {
                path: '/register-vehicle',
                element: <AddVehicles/>
            },
            // {
            //     path:'/edit-vehicle:id',
            //     element:<EditVehicle/>
            // }
            {
                path: '/edit-vehicle/:id',
                element: <EditVehicle/>
            },
            {
                path: '/payment/:id',
                element: <EditVehicle/>
            },

        ]

    }
])
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <LoginProvider>
        <RouterProvider router={routes}>
             <App />
         </RouterProvider>
    </LoginProvider>
);

